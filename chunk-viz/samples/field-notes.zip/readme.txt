Look a little closer. Every file has a structure.
