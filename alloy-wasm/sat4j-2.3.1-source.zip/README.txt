SAT4J 2.3.1 corresponding source

Components: org.sat4j.core, org.sat4j.pb, org.sat4j.maxsat.
Unmodified source files from the Maven Central 2.3.1 source JARs.
Distributed under the Eclipse Public License 1.0; see EPL-1.0.html.
No changes to SAT4J source files were made by this project.

Source artifacts and SHA-256:
sat4j-sources.jar: 09baac3ade77512a59775f41814ac2da97b0e523521422fa4a6a4b2e2052dc81
sat4j-pb-sources.jar: 1c765a3da2b563c6c3582d72d85c43116c3b719c7d63649dd714f593a3b14d72
sat4j-maxsat-sources.jar: f42321411d4255296aa74853d74656565a41099bb1281d4ba8e6f357ec6394a1
